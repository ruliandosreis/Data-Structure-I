#ifndef EP3_SUGERE_H
#define EP3_SUGERE_H

#include <stdio.h>
#include <string.h>

#include "Util.h"
#include "Arvore.h"
#include "Fila.h"

void imprimeSugestao(No *, char *);

#endif